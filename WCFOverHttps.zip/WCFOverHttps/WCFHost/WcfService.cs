﻿using System;
using System.IO;
using System.ServiceModel.Web;

namespace WCFOverHttps.WCFHost
{
    public class WcfService : IWcfHttpService, IWcfSoapService
    {
        public string HelloWorld()
        {
            return "Hello World";
        }

        public Stream GetFile(string path)
        {
            path = string.Format("c:\\{0}", path);
            try
            {
                if (!File.Exists(path))
                    throw new Exception("File not found");

                if (WebOperationContext.Current != null)
                    WebOperationContext.Current.OutgoingResponse.ContentType = "application/octet-stream";

                return File.OpenRead(path);
            }
            catch (Exception ex)
            {
                if (WebOperationContext.Current != null)
                    WebOperationContext.Current.OutgoingResponse.SetStatusAsNotFound(ex.Message);

                return null;
            }
        }
    }
}
