﻿using System.ServiceModel;

namespace WCFOverHttps.WCFHost
{
    [ServiceContract(Namespace = "WCFOverHttps.WCFHost")]
    public interface IWcfSoapService
    {
        [OperationContract]
        string HelloWorld();
    }
}
