﻿using System.IO;
using System.ServiceModel;
using System.ServiceModel.Web;

namespace WCFOverHttps.WCFHost
{
    [ServiceContract(Namespace = "WCFOverHttps.WCFHost")]
    public interface IWcfHttpService
    {
        [OperationContract]
        [WebGet(UriTemplate = "GetFile/{path}")]
        Stream GetFile(string path);
    }
}
