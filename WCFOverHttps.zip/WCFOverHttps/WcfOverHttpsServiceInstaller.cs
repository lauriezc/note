﻿using System;
using System.ComponentModel;
using System.Configuration.Install;
using System.Diagnostics;
using System.IO;
using System.ServiceProcess;


namespace WCFOverHttps
{
    [RunInstaller(true)]
    public partial class WcfOverHttpsServiceInstaller : Installer
    {
        public WcfOverHttpsServiceInstaller()
        {
            InitializeComponent();

            Installers.Add(GetServiceInstaller());
            Installers.Add(GetServiceProcessInstaller());
        }

        public WcfOverHttpsServiceInstaller(IContainer container)
        {
            container.Add(this);

            InitializeComponent();
        }

        private static ServiceInstaller GetServiceInstaller()
        {
            Process pc = Process.GetCurrentProcess();
            Directory.SetCurrentDirectory
            (pc.MainModule.FileName.Substring(0, pc.MainModule.FileName.LastIndexOf(@"\", StringComparison.CurrentCulture)
            ));

            ServiceInstaller installer = new ServiceInstaller
            {
                ServiceName = "WCF Over Https",
                Description = "WCF Over Https"
            };

            return installer;
        }

        private static ServiceProcessInstaller GetServiceProcessInstaller()
        {
            ServiceProcessInstaller installer = new ServiceProcessInstaller { Account = ServiceAccount.LocalSystem };
            return installer;
        }
    }
}
